<?php
	/*
		file name: database.php
	*/

  // Connect to the database management system

	
	//Select the database

	
	//Submit a query to retrieve data from CUSTOMER table

	
	//Retrieve customer data from the query result and populate the array

	
	//Save the array in $_SESSION

	
	//Submit the query for product

	
	//Retrieve product data from the query result and populate the array


	//Save the array in $_SESSION

	
	//Disconnect the database management system
	//mysql_close($dbLocalhost);

?> 